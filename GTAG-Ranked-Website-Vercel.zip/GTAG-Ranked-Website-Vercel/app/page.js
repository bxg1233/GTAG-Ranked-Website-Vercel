'use client';
import { useEffect, useState } from 'react';
const modes=['1v1','2v2','3v3'];
function rankFor(n){return n>=3200?'Champion':n>=2800?'Grandmaster':n>=2400?'Master':n>=2000?'Diamond':n>=1600?'Platinum':n>=1200?'Gold':n>=800?'Silver':'Bronze'}
export default function Home(){
  const [mode,setMode]=useState('1v1'),[rows,setRows]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState('');
  useEffect(()=>{setLoading(true);setError('');fetch(`/api/leaderboard?mode=${mode}`).then(r=>r.json()).then(d=>{if(!d.ok)throw new Error(d.error||'Unable to load leaderboard');setRows(d.rows||[])}).catch(e=>setError(e.message)).finally(()=>setLoading(false))},[mode]);
  return <main className="wrap">
    <section className="hero"><div className="eyebrow">Competitive ladder · Ranked seasons</div><h1>GORILLA TAG<br/>RANKED</h1><p className="muted">Queue up. Prove your skill. Climb the ladder.</p></section>
    <section className="stats">
      <div className="stat"><span className="muted">Ranked modes</span><strong>3</strong><span className="muted">1v1 · 2v2 · 3v3</span></div>
      <div className="stat"><span className="muted">Starting rating</span><strong>1,000</strong><span className="muted">Separate MMR per mode</span></div>
      <div className="stat"><span className="muted">Season ladder</span><strong>Live</strong><span className="muted">Updated after verified reports</span></div>
    </section>
    <div className="toolbar"><div><h2 style={{margin:'0 0 5px'}}>Leaderboard</h2><span className="muted">Top ranked players this season</span></div><label>Mode&nbsp; <select value={mode} onChange={e=>setMode(e.target.value)}>{modes.map(m=><option key={m}>{m}</option>)}</select></label></div>
    <section className="panel">{loading?<p className="muted">Loading leaderboard…</p>:error?<p className="muted">{error}</p>:rows.length===0?<p className="muted">No ranked players yet. Join the Discord and play your first match.</p>:<div style={{overflowX:'auto'}}><table><thead><tr><th>#</th><th>Player</th><th>Rank</th><th>MMR</th><th>W</th><th>L</th></tr></thead><tbody>{rows.map((p,i)=><tr key={p.player_id}><td>{i+1}</td><td>{p.discord_name||p.discord_id}</td><td><span className="rank">{rankFor(p.mmr)}</span></td><td><b>{p.mmr}</b></td><td>{p.wins}</td><td>{p.losses}</td></tr>)}</tbody></table></div>}</section>
    <div className="footer">Match results are accepted only after all participants report a consistent outcome. Client mods are not tamper-proof proof of play.</div>
  </main>
}
