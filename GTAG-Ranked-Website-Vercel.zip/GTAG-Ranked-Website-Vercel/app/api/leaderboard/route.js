import { NextResponse } from 'next/server';
import { supabaseAdmin } from '../../../lib/server';
const modes = new Set(['1v1','2v2','3v3']);
export async function GET(req) {
  try {
    const mode = new URL(req.url).searchParams.get('mode') || '1v1';
    if (!modes.has(mode)) return NextResponse.json({ok:false,error:'Invalid mode'}, {status:400});
    const db = supabaseAdmin();
    const {data,error} = await db.rpc('ranked_leaderboard',{p_mode:mode,p_limit:50});
    if(error) throw error;
    return NextResponse.json({ok:true,rows:data||[]},{headers:{'Cache-Control':'s-maxage=30, stale-while-revalidate=60'}});
  } catch(e) { return NextResponse.json({ok:false,error:'Leaderboard unavailable. Check server configuration.'},{status:500}); }
}
