import { NextResponse } from 'next/server';
import crypto from 'node:crypto';
import { supabaseAdmin } from '../../../../lib/server';

const sha256 = value => crypto.createHash('sha256').update(value, 'utf8').digest('hex');

export async function POST(req) {
  try {
    const body = await req.json();
    const code = String(body?.code || '').trim().toUpperCase();
    const gameId = String(body?.game_id || '').trim();
    const displayName = String(body?.display_name || '').trim();
    if (!/^[A-F0-9]{10}$/.test(code)) return NextResponse.json({ error: 'Connect code must be 10 letters/numbers.' }, { status: 400 });
    if (gameId.length < 16 || gameId.length > 80) return NextResponse.json({ error: 'Invalid mod device ID.' }, { status: 400 });
    if (!displayName || displayName.length > 32) return NextResponse.json({ error: 'Display name must be 1–32 characters.' }, { status: 400 });

    const deviceToken = crypto.randomBytes(32).toString('hex');
    const db = supabaseAdmin();
    const { data, error } = await db.rpc('ranked_mod_connect', {
      p_code_hash: sha256(code),
      p_game_id: gameId,
      p_display_name: displayName,
      p_token_hash: sha256(deviceToken)
    });
    if (error) return NextResponse.json({ error: error.message }, { status: 400 });
    return NextResponse.json({
      ok: true,
      player_id: data.player_id,
      discord_name: data.discord_name,
      display_name: data.display_name,
      device_token: deviceToken
    });
  } catch {
    return NextResponse.json({ error: 'Invalid request body or server configuration.' }, { status: 400 });
  }
}
