import { NextResponse } from 'next/server';
import crypto from 'node:crypto';
import { supabaseAdmin, requireApiSecret } from '../../../../lib/server';
export async function POST(req) {
  if(!requireApiSecret(req)) return NextResponse.json({error:'Unauthorized'}, {status:401});
  try {
    const body=await req.json();
    const {match_id,player_id,ticket}=body||{};
    if(!match_id||!player_id||!ticket) return NextResponse.json({error:'match_id, player_id, ticket required'},{status:400});
    const db=supabaseAdmin();
    const {data,error}=await db.rpc('ranked_mod_ticket',{p_match_id:match_id,p_player_id:player_id,p_ticket:ticket});
    if(error) return NextResponse.json({error:error.message},{status:400});
    return NextResponse.json({ok:true,match:data});
  } catch { return NextResponse.json({error:'Bad request'}, {status:400}); }
}
