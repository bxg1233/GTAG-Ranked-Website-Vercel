import { NextResponse } from 'next/server';
import crypto from 'node:crypto';
import { supabaseAdmin } from '../../../../lib/server';

const sha256 = value => crypto.createHash('sha256').update(value, 'utf8').digest('hex');

export async function POST(req) {
  try {
    const match = (req.headers.get('authorization') || '').match(/^Bearer\s+([a-f0-9]{64})$/i);
    if (!match) return NextResponse.json({ error: 'Missing device token. Run /connect and pair your mod.' }, { status: 401 });
    const body = await req.json();
    const gameId = String(body?.game_id || '').trim();
    const displayName = String(body?.display_name || '').trim();
    const mode = String(body?.mode || '');
    const visibleToRank = String(body?.visible_to_rank || '');
    const inCode = body?.in_code === true;
    const roomCode = inCode ? String(body?.room_code || '').trim().slice(0, 120) : null;
    if (gameId.length < 16 || gameId.length > 80) return NextResponse.json({ error: 'Invalid mod device ID.' }, { status: 400 });
    if (!displayName || displayName.length > 32) return NextResponse.json({ error: 'Invalid display name.' }, { status: 400 });
    if (!['1v1', '2v2', '3v3'].includes(mode)) return NextResponse.json({ error: 'Select 1v1, 2v2, or 3v3 in the mod settings.' }, { status: 400 });
    if (!['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Master', 'Grandmaster', 'Champion', 'ALL'].includes(visibleToRank)) {
      return NextResponse.json({ error: 'Select a rank or ALL in the mod settings.' }, { status: 400 });
    }
    const db = supabaseAdmin();
    const { data, error } = await db.rpc('ranked_mod_heartbeat', {
      p_token_hash: sha256(match[1]),
      p_game_id: gameId,
      p_display_name: displayName,
      p_in_code: inCode,
      p_room_code: roomCode,
      p_mode: mode,
      p_visible_to_rank: visibleToRank
    });
    if (error) return NextResponse.json({ error: error.message }, { status: 401 });
    return NextResponse.json({ ok: true, presence: data });
  } catch {
    return NextResponse.json({ error: 'Invalid request body or server configuration.' }, { status: 400 });
  }
}
