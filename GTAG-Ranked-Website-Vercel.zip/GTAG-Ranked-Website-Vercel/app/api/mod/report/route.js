import { NextResponse } from 'next/server';
import { supabaseAdmin, requireApiSecret } from '../../../../lib/server';
export async function POST(req) {
  if(!requireApiSecret(req)) return NextResponse.json({error:'Unauthorized'}, {status:401});
  try {
    const body=await req.json();
    const {match_id,player_id,ticket,winner,telemetry={}}=body||{};
    if(!match_id||!player_id||!ticket||!['A','B'].includes(winner)) return NextResponse.json({error:'Invalid report fields'}, {status:400});
    const db=supabaseAdmin();
    const {data,error}=await db.rpc('ranked_mod_report',{p_match_id:match_id,p_player_id:player_id,p_ticket:ticket,p_winner:winner,p_telemetry:telemetry});
    if(error) return NextResponse.json({error:error.message},{status:400});
    return NextResponse.json({ok:true,result:data});
  } catch { return NextResponse.json({error:'Bad request'}, {status:400}); }
}
