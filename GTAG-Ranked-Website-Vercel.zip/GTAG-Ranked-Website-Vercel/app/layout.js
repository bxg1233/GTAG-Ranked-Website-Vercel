import './globals.css';
export const metadata = { title: 'Gorilla Tag Ranked', description: 'Competitive Gorilla Tag ranked ladder' };
export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
