# Gorilla Tag Ranked Website — Vercel deployment

This is the **website-only** package. It puts the Next.js leaderboard/API at the repository root so Vercel can detect Next.js automatically. It is not a pre-deployed site; publish it through your own Vercel/GitHub accounts.

## 1. Prepare Supabase

For a **brand-new Supabase project**, open **SQL Editor** and run:

1. `supabase/schema.sql`
2. `supabase/START_HERE.sql`

The second script creates Season 1 only if no active season exists.

If you already use the ranked system's Supabase database, **do not run the full schema again**. Check the project's current schema first; run `supabase/QUEUE_CONNECT_MIGRATION.sql` only if you are updating the previous ranked-system schema to add the pairing/presence endpoints described in the main project README.

## 2. Put this folder in GitHub

Create a new repository in GitHub, then upload the **contents** of this folder (not the outer folder itself). Commit the files to the default branch. Keep `.env`, tokens, and service-role keys out of GitHub.

## 3. Deploy with Vercel

1. Open the Vercel dashboard and choose **Add New → Project**.
2. Import the GitHub repository you just created.
3. Framework preset should be **Next.js**. The Root Directory is the repository root (`./`); leave it there.
4. Before deploying, add these Environment Variables to the project:
   - `SUPABASE_URL` — the URL from Supabase Project Settings → API.
   - `SUPABASE_SERVICE_ROLE_KEY` — the service-role key from Supabase Project Settings → API. Keep this server-side only; never use a `NEXT_PUBLIC_` prefix.
   - `RANKED_API_SECRET` — a random secret at least 32 characters long, needed only by the legacy `/api/mod/ticket` and `/api/mod/report` routes.
5. Deploy. After any later environment-variable change, redeploy the project.

## 4. Smoke test

Open the Vercel deployment URL. The site should load, then the leaderboard API should return JSON at `/api/leaderboard?mode=1v1`. If you see “Leaderboard unavailable”, verify `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, the database functions, and that an active season exists.

## Supported website modes

The website leaderboard selector currently matches the Discord ranked bot/queue modes: `1v1`, `2v2`, and `3v3`.
