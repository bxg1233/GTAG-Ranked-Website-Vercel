const path = require('node:path');
// Load the shared root .env during local development. Vercel uses its configured environment variables.
try {
  require('dotenv').config({ path: path.resolve(__dirname, '.env') });
} catch (error) {
  // Vercel provides environment variables itself; missing local .env is okay during deployment.
}
/** @type {import('next').NextConfig} */
const nextConfig = {};
module.exports = nextConfig;
