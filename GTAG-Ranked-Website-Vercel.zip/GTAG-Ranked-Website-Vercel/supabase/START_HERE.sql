-- Run schema.sql first, then run this once to create the initial season.
insert into public.ranked_seasons(name)
select 'Season 1'
where not exists (select 1 from public.ranked_seasons where active = true);
