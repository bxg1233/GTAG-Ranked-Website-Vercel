create extension if not exists pgcrypto;

create table if not exists public.ranked_players (
  id uuid primary key default gen_random_uuid(),
  discord_id text unique not null,
  discord_name text not null,
  created_at timestamptz not null default now(),
  linked_game_id text unique,
  is_banned boolean not null default false
);

create table if not exists public.ranked_seasons (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  starts_at timestamptz not null default now(),
  ends_at timestamptz,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index if not exists one_active_ranked_season on public.ranked_seasons(active) where active = true;

create table if not exists public.ranked_ratings (
  player_id uuid references public.ranked_players(id) on delete cascade,
  season_id uuid references public.ranked_seasons(id) on delete cascade,
  mode text not null check (mode in ('1v1','2v2','3v3','4v4')),
  mmr integer not null default 1000 check (mmr between 0 and 5000),
  peak_mmr integer not null default 1000,
  wins integer not null default 0,
  losses integer not null default 0,
  games_played integer not null default 0,
  last_match_at timestamptz,
  last_active_at timestamptz not null default now(),
  protected_until timestamptz not null default (now() + interval '7 days'),
  primary key(player_id, season_id, mode)
);

create table if not exists public.ranked_matches (
  id uuid primary key default gen_random_uuid(),
  season_id uuid references public.ranked_seasons(id),
  mode text not null check (mode in ('1v1','2v2','3v3','4v4')),
  status text not null default 'pending_reports' check (status in ('pending_reports','verified','disputed','cancelled')),
  team_a uuid[] not null,
  team_b uuid[] not null,
  ticket_hash text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '30 minutes'),
  completed_at timestamptz,
  winner text check (winner in ('A','B')),
  report_count integer not null default 0,
  result_json jsonb
);

create table if not exists public.ranked_match_reports (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.ranked_matches(id) on delete cascade,
  player_id uuid not null references public.ranked_players(id) on delete cascade,
  winner text not null check (winner in ('A','B')),
  telemetry jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(match_id, player_id)
);

create table if not exists public.ranked_queue (
  player_id uuid primary key references public.ranked_players(id) on delete cascade,
  mode text not null check (mode in ('1v1','2v2','3v3','4v4')),
  mmr_snapshot integer not null,
  joined_at timestamptz not null default now()
);

create table if not exists public.ranked_challenges (
  id uuid primary key default gen_random_uuid(),
  challenger_id uuid not null references public.ranked_players(id),
  opponent_id uuid not null references public.ranked_players(id),
  mode text not null check (mode in ('1v1','2v2','3v3','4v4')),
  status text not null default 'pending' check (status in ('pending','accepted','declined','expired')),
  match_id uuid references public.ranked_matches(id),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '10 minutes'),
  check (challenger_id <> opponent_id)
);

create table if not exists public.ranked_mmr_history (
  id bigserial primary key,
  match_id uuid references public.ranked_matches(id),
  player_id uuid not null references public.ranked_players(id),
  mode text not null,
  old_mmr integer not null,
  new_mmr integer not null,
  delta integer not null,
  created_at timestamptz not null default now()
);

create table if not exists public.ranked_admin_audit (
  id bigserial primary key,
  admin_discord_id text not null,
  action text not null,
  detail jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.ranked_players enable row level security;
alter table public.ranked_seasons enable row level security;
alter table public.ranked_ratings enable row level security;
alter table public.ranked_matches enable row level security;
alter table public.ranked_match_reports enable row level security;
alter table public.ranked_queue enable row level security;
alter table public.ranked_challenges enable row level security;
alter table public.ranked_mmr_history enable row level security;
alter table public.ranked_admin_audit enable row level security;
-- No anon policies are intentionally created. Server-side service-role routes perform access-controlled operations.

create or replace function public.ranked_upsert_discord_player(p_discord_id text, p_discord_name text)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_player uuid; v_season uuid;
begin
  insert into ranked_players(discord_id, discord_name) values (p_discord_id, p_discord_name)
  on conflict(discord_id) do update set discord_name=excluded.discord_name
  returning id into v_player;
  select id into v_season from ranked_seasons where active=true limit 1;
  if v_season is not null then
    insert into ranked_ratings(player_id,season_id,mode)
    select v_player,v_season,m from unnest(array['1v1','2v2','3v3','4v4']) m
    on conflict do nothing;
  end if;
  return v_player;
end $$;

create or replace function public.ranked_current_season()
returns table(id uuid,name text,starts_at timestamptz)
language sql security definer set search_path=public as $$
  select s.id,s.name,s.starts_at from ranked_seasons s where s.active=true order by starts_at desc limit 1
$$;

create or replace function public.ranked_start_season(p_name text)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_season uuid;
begin
  update ranked_seasons set active=false, ends_at=now() where active=true;
  insert into ranked_seasons(name) values (p_name) returning id into v_season;
  insert into ranked_ratings(player_id,season_id,mode)
  select p.id,v_season,m from ranked_players p cross join unnest(array['1v1','2v2','3v3','4v4']) m
  on conflict do nothing;
  return v_season;
end $$;

create or replace function public.ranked_get_profile(p_player_id uuid,p_mode text)
returns table(player_id uuid,mmr integer,peak_mmr integer,wins integer,losses integer,games_played integer,division text)
language plpgsql security definer set search_path=public as $$
declare v_season uuid;
begin
  select id into v_season from ranked_seasons where active=true limit 1;
  return query select r.player_id,r.mmr,r.peak_mmr,r.wins,r.losses,r.games_played,
    case when r.mmr % 400 >= 267 then 'I' when r.mmr % 400 >= 134 then 'II' else 'III' end
  from ranked_ratings r where r.player_id=p_player_id and r.mode=p_mode and r.season_id=v_season;
end $$;

create or replace function public.ranked_leaderboard(p_mode text,p_limit integer default 10)
returns table(player_id uuid,discord_id text,discord_name text,mmr integer,wins integer,losses integer,games_played integer)
language plpgsql security definer set search_path=public as $$
declare v_season uuid;
begin
  select id into v_season from ranked_seasons where active=true limit 1;
  return query select p.id,p.discord_id,p.discord_name,r.mmr,r.wins,r.losses,r.games_played
  from ranked_ratings r join ranked_players p on p.id=r.player_id
  where r.season_id=v_season and r.mode=p_mode and not p.is_banned
  order by r.mmr desc,r.wins desc limit greatest(1,least(p_limit,100));
end $$;

create or replace function public.ranked_queue_join(p_player_id uuid,p_mode text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_season uuid; v_mmr integer; v_id uuid:=gen_random_uuid();
begin
  if p_mode not in ('1v1','2v2','3v3','4v4') then raise exception 'Invalid mode'; end if;
  if exists(select 1 from ranked_players where id=p_player_id and is_banned) then raise exception 'ranked_banned'; end if;
  select id into v_season from ranked_seasons where active=true limit 1;
  if v_season is null then raise exception 'No active season. Ask an admin to run /rankedadmin season_start.'; end if;
  select mmr into v_mmr from ranked_ratings where player_id=p_player_id and season_id=v_season and mode=p_mode;
  if v_mmr is null then
    insert into ranked_ratings(player_id,season_id,mode) values(p_player_id,v_season,p_mode) returning mmr into v_mmr;
  end if;
  insert into ranked_queue(player_id,mode,mmr_snapshot) values(p_player_id,p_mode,v_mmr)
  on conflict(player_id) do update set mode=excluded.mode,mmr_snapshot=excluded.mmr_snapshot,joined_at=now();
  return jsonb_build_object('queue_id',v_id,'mode',p_mode,'mmr',v_mmr,'status','queued');
end $$;

create or replace function public.ranked_queue_leave(p_player_id uuid)
returns boolean language sql security definer set search_path=public as $$
  with d as (delete from ranked_queue where player_id=p_player_id returning player_id) select exists(select 1 from d)
$$;

create or replace function public.ranked_challenge_create(p_challenger_id uuid,p_opponent_id uuid,p_mode text)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
  if p_challenger_id=p_opponent_id then raise exception 'Cannot challenge yourself'; end if;
  if p_mode not in ('1v1','2v2','3v3','4v4') then raise exception 'Invalid mode'; end if;
  insert into ranked_challenges(challenger_id,opponent_id,mode) values(p_challenger_id,p_opponent_id,p_mode) returning id into v_id;
  return v_id;
end $$;

create or replace function public.ranked_challenge_accept(p_challenge_id uuid,p_player_id uuid)
returns uuid language plpgsql security definer set search_path=public as $$
declare c ranked_challenges%rowtype; v_season uuid; v_match uuid; v_ticket text;
begin
  select * into c from ranked_challenges where id=p_challenge_id for update;
  if not found or c.status <> 'pending' or c.expires_at < now() then raise exception 'Challenge unavailable or expired'; end if;
  if c.mode <> '1v1' then raise exception 'Direct challenges currently support 1v1 only; use ranked queues for team modes.'; end if;
  if c.opponent_id <> p_player_id then raise exception 'Only the challenged player can accept'; end if;
  select id into v_season from ranked_seasons where active=true limit 1;
  if v_season is null then raise exception 'No active season'; end if;
  v_ticket := encode(gen_random_bytes(32),'hex');
  insert into ranked_matches(season_id,mode,team_a,team_b,ticket_hash,expires_at)
    values(v_season,c.mode,array[c.challenger_id],array[c.opponent_id],encode(digest(v_ticket,'sha256'),'hex'),now()+interval '30 minutes')
    returning id into v_match;
  update ranked_challenges set status='accepted',match_id=v_match where id=c.id;
  return v_match;
end $$;

create or replace function public.ranked_challenge_decline(p_challenge_id uuid,p_player_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
begin
  update ranked_challenges set status='declined' where id=p_challenge_id and opponent_id=p_player_id and status='pending';
  if not found then raise exception 'Challenge unavailable'; end if;
  return true;
end $$;

create or replace function public.ranked_admin_set_mmr(p_player_id uuid,p_mode text,p_mmr integer,p_admin_discord_id text)
returns boolean language plpgsql security definer set search_path=public as $$
declare v_season uuid; v_old integer;
begin
  if p_mmr<0 or p_mmr>5000 then raise exception 'MMR must be between 0 and 5000'; end if;
  select id into v_season from ranked_seasons where active=true limit 1;
  insert into ranked_ratings(player_id,season_id,mode,mmr,peak_mmr)
    values(p_player_id,v_season,p_mode,p_mmr,p_mmr)
  on conflict(player_id,season_id,mode) do update set mmr=excluded.mmr,peak_mmr=greatest(ranked_ratings.peak_mmr,excluded.mmr);
  insert into ranked_admin_audit(admin_discord_id,action,detail) values(p_admin_discord_id,'set_mmr',jsonb_build_object('player_id',p_player_id,'mode',p_mode,'mmr',p_mmr));
  return true;
end $$;

create or replace function public.ranked_apply_inactivity_decay(p_dry_run boolean default true)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_count integer:=0;
begin
  -- Rank protection: new/returning players are protected for 7 days.
  -- Decay: after 30 inactive days, subtract 10 MMR per full week, max 100 per run, never below 800.
  if p_dry_run then
    select count(*) into v_count from ranked_ratings where last_active_at < now()-interval '30 days' and protected_until < now() and mmr > 800;
    return jsonb_build_object('dry_run',true,'eligible_rows',v_count);
  end if;
  update ranked_ratings set mmr=greatest(800,mmr-least(100,10*floor(extract(epoch from (now()-last_active_at))/604800)::integer))
    where last_active_at < now()-interval '30 days' and protected_until < now() and mmr>800;
  get diagnostics v_count = row_count;
  return jsonb_build_object('dry_run',false,'updated_rows',v_count);
end $$;

create or replace function public.ranked_mod_ticket(p_match_id uuid,p_player_id uuid,p_ticket text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare m ranked_matches%rowtype;
begin
  select * into m from ranked_matches where id=p_match_id for update;
  if not found or m.expires_at < now() or m.status <> 'pending_reports' then raise exception 'Match ticket unavailable'; end if;
  if not (p_player_id=any(m.team_a) or p_player_id=any(m.team_b)) then raise exception 'Player not in match'; end if;
  if encode(digest(p_ticket,'sha256'),'hex') <> m.ticket_hash then raise exception 'Invalid ticket'; end if;
  return jsonb_build_object('match_id',m.id,'mode',m.mode,'team_a',m.team_a,'team_b',m.team_b,'expires_at',m.expires_at);
end $$;

create or replace function public.ranked_mod_report(p_match_id uuid,p_player_id uuid,p_ticket text,p_winner text,p_telemetry jsonb default '{}'::jsonb)
returns jsonb language plpgsql security definer set search_path=public as $$
declare m ranked_matches%rowtype; n integer; min_reports integer; winners integer; v_season uuid;
begin
  if p_winner not in ('A','B') then raise exception 'Invalid winner'; end if;
  select * into m from ranked_matches where id=p_match_id for update;
  if not found or m.expires_at < now() or m.status <> 'pending_reports' then raise exception 'Match is not reportable'; end if;
  if encode(digest(p_ticket,'sha256'),'hex') <> m.ticket_hash then raise exception 'Invalid ticket'; end if;
  if not (p_player_id=any(m.team_a) or p_player_id=any(m.team_b)) then raise exception 'Player not in match'; end if;
  insert into ranked_match_reports(match_id,player_id,winner,telemetry)
    values(m.id,p_player_id,p_winner,coalesce(p_telemetry,'{}'::jsonb))
    on conflict(match_id,player_id) do nothing;
  select count(*),count(*) filter(where winner=p_winner) into n,winners from ranked_match_reports where match_id=m.id;
  min_reports := cardinality(m.team_a)+cardinality(m.team_b);
  if n < min_reports then
    update ranked_matches set report_count=n where id=m.id;
    return jsonb_build_object('status','awaiting_reports','reports',n,'required',min_reports);
  end if;
  if exists(select 1 from ranked_match_reports where match_id=m.id group by winner having count(*)>0) and
     (select count(distinct winner) from ranked_match_reports where match_id=m.id)>1 then
    update ranked_matches set status='disputed',report_count=n where id=m.id;
    return jsonb_build_object('status','disputed','reports',n);
  end if;
  update ranked_matches set status='verified',winner=p_winner,completed_at=now(),report_count=n where id=m.id;
  perform ranked_apply_match_mmr(m.id,p_winner);
  return jsonb_build_object('status','verified','winner',p_winner,'reports',n);
end $$;

create or replace function public.ranked_apply_match_mmr(p_match_id uuid,p_winner text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare m ranked_matches%rowtype; r record; v_expected numeric; v_actual numeric; v_delta integer; v_old integer; v_new integer; v_team_a numeric; v_team_b numeric; v_k integer:=32;
begin
  select * into m from ranked_matches where id=p_match_id for update;
  if not found or m.status<>'verified' then raise exception 'Match must be verified first'; end if;
  select coalesce(avg(mmr),1000) into v_team_a from ranked_ratings where season_id=m.season_id and mode=m.mode and player_id=any(m.team_a);
  select coalesce(avg(mmr),1000) into v_team_b from ranked_ratings where season_id=m.season_id and mode=m.mode and player_id=any(m.team_b);
  v_expected := 1/(1+power(10::numeric,(v_team_b-v_team_a)/400));
  v_actual := case when p_winner='A' then 1 else 0 end;
  for r in
    select p.id as player_id, case when p.id=any(m.team_a) then 'A' else 'B' end as side
    from ranked_players p where p.id=any(m.team_a) or p.id=any(m.team_b)
  loop
    select mmr into v_old from ranked_ratings where player_id=r.player_id and season_id=m.season_id and mode=m.mode for update;
    if v_old is null then
      insert into ranked_ratings(player_id,season_id,mode) values(r.player_id,m.season_id,m.mode) on conflict do nothing;
      select mmr into v_old from ranked_ratings where player_id=r.player_id and season_id=m.season_id and mode=m.mode for update;
    end if;
    if r.side='A' then v_delta:=round(v_k*(v_actual-v_expected)); else v_delta:=round(v_k*((1-v_actual)-(1-v_expected))); end if;
    v_new:=greatest(0,least(5000,v_old+v_delta));
    update ranked_ratings set mmr=v_new,peak_mmr=greatest(peak_mmr,v_new),
      wins=wins+case when (r.side=p_winner) then 1 else 0 end,
      losses=losses+case when (r.side<>p_winner) then 1 else 0 end,
      games_played=games_played+1,last_match_at=now(),last_active_at=now()
      where player_id=r.player_id and season_id=m.season_id and mode=m.mode;
    insert into ranked_mmr_history(match_id,player_id,mode,old_mmr,new_mmr,delta)
      values(m.id,r.player_id,m.mode,v_old,v_new,v_new-v_old);
  end loop;
  return jsonb_build_object('status','applied','team_a_mmr',v_team_a,'team_b_mmr',v_team_b);
end $$;

-- SECURITY DEFINER RPCs are callable by service_role only. Do not grant them to anon/authenticated.
revoke all on all tables in schema public from anon, authenticated;
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on all functions in schema public to service_role;
grant all on all tables in schema public to service_role;

-- Start first season once:
-- insert into public.ranked_seasons(name) values ('Season 1');
-- Run this after the original schema.sql. Safe to run more than once.
create extension if not exists pgcrypto;

alter table public.ranked_players add column if not exists game_display_name text;
alter table public.ranked_players add column if not exists mod_token_hash text;
create unique index if not exists ranked_players_mod_token_hash_uq
  on public.ranked_players(mod_token_hash) where mod_token_hash is not null;
create unique index if not exists ranked_players_linked_game_id_uq
  on public.ranked_players(linked_game_id) where linked_game_id is not null;

create table if not exists public.ranked_connect_codes (
  id uuid primary key default gen_random_uuid(),
  player_id uuid not null references public.ranked_players(id) on delete cascade,
  code_hash text not null unique,
  suggested_name text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '10 minutes'),
  consumed_at timestamptz
);

create table if not exists public.ranked_mod_presence (
  player_id uuid primary key references public.ranked_players(id) on delete cascade,
  in_code boolean not null default false,
  room_code text,
  selected_mode text not null default '1v1' check (selected_mode in ('1v1','2v2','3v3')),
  visible_to_rank text not null default 'ALL' check (visible_to_rank in ('Bronze','Silver','Gold','Platinum','Diamond','Master','Grandmaster','Champion','ALL')),
  last_seen_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.ranked_connect_codes enable row level security;
alter table public.ranked_mod_presence enable row level security;

create or replace function public.ranked_create_connect_code(
  p_player_id uuid, p_code_hash text, p_suggested_name text
) returns jsonb language plpgsql security definer set search_path=public as $$
begin
  if p_code_hash !~ '^[a-f0-9]{64}$' then raise exception 'Invalid verification code'; end if;
  if length(btrim(p_suggested_name)) < 1 or length(p_suggested_name) > 32 then raise exception 'Suggested name must be 1-32 characters'; end if;
  if not exists (select 1 from ranked_players where id=p_player_id) then raise exception 'Player account not found'; end if;
  delete from ranked_connect_codes where player_id=p_player_id and consumed_at is null;
  insert into ranked_connect_codes(player_id,code_hash,suggested_name,expires_at)
    values(p_player_id,p_code_hash,p_suggested_name,now()+interval '10 minutes');
  return jsonb_build_object('expires_at',now()+interval '10 minutes','suggested_name',p_suggested_name);
end $$;

create or replace function public.ranked_mod_connect(
  p_code_hash text, p_game_id text, p_display_name text, p_token_hash text
) returns jsonb language plpgsql security definer set search_path=public as $$
declare v_code ranked_connect_codes%rowtype; v_player ranked_players%rowtype;
begin
  if p_game_id is null or length(p_game_id) < 16 or length(p_game_id) > 80 then raise exception 'Invalid mod device ID'; end if;
  if p_token_hash !~ '^[a-f0-9]{64}$' then raise exception 'Invalid mod token'; end if;
  select * into v_code from ranked_connect_codes
    where code_hash=p_code_hash and consumed_at is null for update;
  if not found or v_code.expires_at < now() then raise exception 'Code expired or invalid. Run /connect again.'; end if;
  if lower(btrim(p_display_name)) <> lower(btrim(v_code.suggested_name)) then
    raise exception 'Use the exact name shown by /connect in the mod settings.';
  end if;
  if exists(select 1 from ranked_players where linked_game_id=p_game_id and id<>v_code.player_id) then
    raise exception 'This mod device is already linked to a different Discord account.';
  end if;
  delete from ranked_queue where player_id=v_code.player_id;
  delete from ranked_mod_presence where player_id=v_code.player_id;
  update ranked_players set linked_game_id=p_game_id, game_display_name=v_code.suggested_name,
    mod_token_hash=p_token_hash where id=v_code.player_id returning * into v_player;
  update ranked_connect_codes set consumed_at=now() where id=v_code.id;
  return jsonb_build_object('player_id',v_player.id,'discord_name',v_player.discord_name,'display_name',v_player.game_display_name);
end $$;

create or replace function public.ranked_mod_heartbeat(
  p_token_hash text, p_game_id text, p_display_name text, p_in_code boolean,
  p_room_code text, p_mode text, p_visible_to_rank text
) returns jsonb language plpgsql security definer set search_path=public as $$
declare v_player ranked_players%rowtype; v_in_code boolean; v_room text;
begin
  if p_mode not in ('1v1','2v2','3v3') then raise exception 'Choose 1v1, 2v2, or 3v3 in the mod settings.'; end if;
  if p_visible_to_rank not in ('Bronze','Silver','Gold','Platinum','Diamond','Master','Grandmaster','Champion','ALL') then
    raise exception 'Invalid rank visibility. Choose a rank or ALL.';
  end if;
  select * into v_player from ranked_players
    where mod_token_hash=p_token_hash and linked_game_id=p_game_id and not is_banned for update;
  if not found then raise exception 'Mod account is not connected. Run /connect in Discord and enter the new code in the mod settings.'; end if;
  v_in_code := coalesce(p_in_code,false) and p_room_code is not null and length(btrim(p_room_code))>0;
  v_room := case when v_in_code then left(btrim(p_room_code),120) else null end;
  update ranked_players set game_display_name=left(btrim(coalesce(nullif(p_display_name,''),game_display_name)),32)
    where id=v_player.id;
  insert into ranked_mod_presence(player_id,in_code,room_code,selected_mode,visible_to_rank,last_seen_at,updated_at)
    values(v_player.id,v_in_code,v_room,p_mode,p_visible_to_rank,now(),now())
  on conflict(player_id) do update set in_code=excluded.in_code,room_code=excluded.room_code,
    selected_mode=excluded.selected_mode,visible_to_rank=excluded.visible_to_rank,
    last_seen_at=now(),updated_at=now();
  return jsonb_build_object('ok',true,'in_code',v_in_code,'selected_mode',p_mode,'visible_to_rank',p_visible_to_rank,'last_seen_at',now());
end $$;

create or replace function public.ranked_mod_disconnect(p_player_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
begin
  delete from ranked_queue where player_id=p_player_id;
  delete from ranked_mod_presence where player_id=p_player_id;
  update ranked_players set linked_game_id=null,game_display_name=null,mod_token_hash=null where id=p_player_id;
  return true;
end $$;

create or replace function public.ranked_queue_join(p_player_id uuid,p_mode text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_season uuid; v_mmr integer; v_filter text; v_seen timestamptz; v_in_code boolean; v_selected_mode text;
begin
  if p_mode not in ('1v1','2v2','3v3') then raise exception 'Queue modes are 1v1, 2v2, and 3v3.'; end if;
  if exists(select 1 from ranked_players where id=p_player_id and is_banned) then raise exception 'This account is not allowed to use ranked queues.'; end if;
  if not exists(select 1 from ranked_players where id=p_player_id and linked_game_id is not null and mod_token_hash is not null) then
    raise exception 'Connect your Gorilla Tag account first: run /connect and follow the mod instructions.';
  end if;
  select last_seen_at,in_code,selected_mode,visible_to_rank into v_seen,v_in_code,v_selected_mode,v_filter
    from ranked_mod_presence where player_id=p_player_id;
  if v_seen is null or v_seen < now()-interval '45 seconds' then
    raise exception 'Your mod is not reporting recently. Open Gorilla Tag with the ranked mod enabled and try again.';
  end if;
  if not v_in_code then raise exception 'Join a Gorilla Tag room/code first; the queue only lists players currently in a room.'; end if;
  if v_selected_mode<>p_mode then raise exception 'Your mod game mode is % but you selected %. Change the mod SelectedMode setting to match, then retry.',v_selected_mode,p_mode; end if;
  if v_filter is null then raise exception 'Select a rank or ALL in the mod settings first.'; end if;
  select id into v_season from ranked_seasons where active=true limit 1;
  if v_season is null then raise exception 'No active ranked season. Ask an admin to run /rankedadmin season_start.'; end if;
  select mmr into v_mmr from ranked_ratings where player_id=p_player_id and season_id=v_season and mode=p_mode;
  if v_mmr is null then
    insert into ranked_ratings(player_id,season_id,mode) values(p_player_id,v_season,p_mode) on conflict do nothing;
    select mmr into v_mmr from ranked_ratings where player_id=p_player_id and season_id=v_season and mode=p_mode;
  end if;
  insert into ranked_queue(player_id,mode,mmr_snapshot,joined_at)
    values(p_player_id,p_mode,v_mmr,now())
  on conflict(player_id) do update set mode=excluded.mode,mmr_snapshot=excluded.mmr_snapshot,joined_at=now();
  return jsonb_build_object('status','queued','mode',p_mode,'mmr',v_mmr,'visible_to_rank',v_filter,'queue_time',now());
end $$;

create or replace function public.ranked_queue_list(p_player_id uuid,p_mode text)
returns table(
  player_id uuid, discord_id text, discord_name text, game_display_name text,
  mmr integer, rank_name text, visible_to_rank text, room_code text, joined_at timestamptz
) language plpgsql security definer set search_path=public as $$
declare v_season uuid; v_mmr integer; v_rank text; v_seen timestamptz; v_in_code boolean; v_mode text;
begin
  if p_mode not in ('1v1','2v2','3v3') then raise exception 'Queue modes are 1v1, 2v2, and 3v3.'; end if;
  if not exists(select 1 from ranked_queue where ranked_queue.player_id=p_player_id and ranked_queue.mode=p_mode) then
    raise exception 'Join this mode first by running /queue with the same mode.';
  end if;
  select last_seen_at,in_code,selected_mode into v_seen,v_in_code,v_mode from ranked_mod_presence where ranked_mod_presence.player_id=p_player_id;
  if v_seen is null or v_seen < now()-interval '45 seconds' or not v_in_code or v_mode<>p_mode then
    raise exception 'Your mod must be online, in a room, and set to the selected mode to view the queue.';
  end if;
  select id into v_season from ranked_seasons where active=true limit 1;
  select mmr into v_mmr from ranked_ratings where ranked_ratings.player_id=p_player_id and season_id=v_season and mode=p_mode;
  v_rank := case when v_mmr >= 3200 then 'Champion' when v_mmr >= 2800 then 'Grandmaster'
    when v_mmr >= 2400 then 'Master' when v_mmr >= 2000 then 'Diamond'
    when v_mmr >= 1600 then 'Platinum' when v_mmr >= 1200 then 'Gold'
    when v_mmr >= 800 then 'Silver' else 'Bronze' end;
  return query
  select p.id,p.discord_id,p.discord_name,p.game_display_name,r.mmr,
    case when r.mmr >= 3200 then 'Champion' when r.mmr >= 2800 then 'Grandmaster'
      when r.mmr >= 2400 then 'Master' when r.mmr >= 2000 then 'Diamond'
      when r.mmr >= 1600 then 'Platinum' when r.mmr >= 1200 then 'Gold'
      when r.mmr >= 800 then 'Silver' else 'Bronze' end as rank_name,
    pr.visible_to_rank,pr.room_code,q.joined_at
  from ranked_queue q
  join ranked_players p on p.id=q.player_id and not p.is_banned and p.linked_game_id is not null
  join ranked_mod_presence pr on pr.player_id=p.id
  join ranked_ratings r on r.player_id=p.id and r.season_id=v_season and r.mode=p_mode
  where q.mode=p_mode and q.player_id<>p_player_id
    and pr.in_code=true and pr.room_code is not null
    and pr.last_seen_at >= now()-interval '45 seconds'
    and pr.selected_mode=p_mode
    -- The other player's mod must allow this viewer's current rank, or ALL ranks.
    and (pr.visible_to_rank='ALL' or pr.visible_to_rank=v_rank)
  order by r.mmr desc,q.joined_at asc;
end $$;

-- Every security-definer RPC remains server-only. Never grant these functions to anon/authenticated.
revoke all on all tables in schema public from anon, authenticated;
grant all on all tables in schema public to service_role;
revoke all on all functions in schema public from public, anon, authenticated;
grant execute on all functions in schema public to service_role;
