-- Run this after the original schema.sql. Safe to run more than once.
create extension if not exists pgcrypto;

alter table public.ranked_players add column if not exists game_display_name text;
alter table public.ranked_players add column if not exists mod_token_hash text;
create unique index if not exists ranked_players_mod_token_hash_uq
  on public.ranked_players(mod_token_hash) where mod_token_hash is not null;
create unique index if not exists ranked_players_linked_game_id_uq
  on public.ranked_players(linked_game_id) where linked_game_id is not null;

create table if not exists public.ranked_connect_codes (
  id uuid primary key default gen_random_uuid(),
  player_id uuid not null references public.ranked_players(id) on delete cascade,
  code_hash text not null unique,
  suggested_name text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '10 minutes'),
  consumed_at timestamptz
);

create table if not exists public.ranked_mod_presence (
  player_id uuid primary key references public.ranked_players(id) on delete cascade,
  in_code boolean not null default false,
  room_code text,
  selected_mode text not null default '1v1' check (selected_mode in ('1v1','2v2','3v3')),
  visible_to_rank text not null default 'ALL' check (visible_to_rank in ('Bronze','Silver','Gold','Platinum','Diamond','Master','Grandmaster','Champion','ALL')),
  last_seen_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.ranked_connect_codes enable row level security;
alter table public.ranked_mod_presence enable row level security;

create or replace function public.ranked_create_connect_code(
  p_player_id uuid, p_code_hash text, p_suggested_name text
) returns jsonb language plpgsql security definer set search_path=public as $$
begin
  if p_code_hash !~ '^[a-f0-9]{64}$' then raise exception 'Invalid verification code'; end if;
  if length(btrim(p_suggested_name)) < 1 or length(p_suggested_name) > 32 then raise exception 'Suggested name must be 1-32 characters'; end if;
  if not exists (select 1 from ranked_players where id=p_player_id) then raise exception 'Player account not found'; end if;
  delete from ranked_connect_codes where player_id=p_player_id and consumed_at is null;
  insert into ranked_connect_codes(player_id,code_hash,suggested_name,expires_at)
    values(p_player_id,p_code_hash,p_suggested_name,now()+interval '10 minutes');
  return jsonb_build_object('expires_at',now()+interval '10 minutes','suggested_name',p_suggested_name);
end $$;

create or replace function public.ranked_mod_connect(
  p_code_hash text, p_game_id text, p_display_name text, p_token_hash text
) returns jsonb language plpgsql security definer set search_path=public as $$
declare v_code ranked_connect_codes%rowtype; v_player ranked_players%rowtype;
begin
  if p_game_id is null or length(p_game_id) < 16 or length(p_game_id) > 80 then raise exception 'Invalid mod device ID'; end if;
  if p_token_hash !~ '^[a-f0-9]{64}$' then raise exception 'Invalid mod token'; end if;
  select * into v_code from ranked_connect_codes
    where code_hash=p_code_hash and consumed_at is null for update;
  if not found or v_code.expires_at < now() then raise exception 'Code expired or invalid. Run /connect again.'; end if;
  if lower(btrim(p_display_name)) <> lower(btrim(v_code.suggested_name)) then
    raise exception 'Use the exact name shown by /connect in the mod settings.';
  end if;
  if exists(select 1 from ranked_players where linked_game_id=p_game_id and id<>v_code.player_id) then
    raise exception 'This mod device is already linked to a different Discord account.';
  end if;
  delete from ranked_queue where player_id=v_code.player_id;
  delete from ranked_mod_presence where player_id=v_code.player_id;
  update ranked_players set linked_game_id=p_game_id, game_display_name=v_code.suggested_name,
    mod_token_hash=p_token_hash where id=v_code.player_id returning * into v_player;
  update ranked_connect_codes set consumed_at=now() where id=v_code.id;
  return jsonb_build_object('player_id',v_player.id,'discord_name',v_player.discord_name,'display_name',v_player.game_display_name);
end $$;

create or replace function public.ranked_mod_heartbeat(
  p_token_hash text, p_game_id text, p_display_name text, p_in_code boolean,
  p_room_code text, p_mode text, p_visible_to_rank text
) returns jsonb language plpgsql security definer set search_path=public as $$
declare v_player ranked_players%rowtype; v_in_code boolean; v_room text;
begin
  if p_mode not in ('1v1','2v2','3v3') then raise exception 'Choose 1v1, 2v2, or 3v3 in the mod settings.'; end if;
  if p_visible_to_rank not in ('Bronze','Silver','Gold','Platinum','Diamond','Master','Grandmaster','Champion','ALL') then
    raise exception 'Invalid rank visibility. Choose a rank or ALL.';
  end if;
  select * into v_player from ranked_players
    where mod_token_hash=p_token_hash and linked_game_id=p_game_id and not is_banned for update;
  if not found then raise exception 'Mod account is not connected. Run /connect in Discord and enter the new code in the mod settings.'; end if;
  v_in_code := coalesce(p_in_code,false) and p_room_code is not null and length(btrim(p_room_code))>0;
  v_room := case when v_in_code then left(btrim(p_room_code),120) else null end;
  update ranked_players set game_display_name=left(btrim(coalesce(nullif(p_display_name,''),game_display_name)),32)
    where id=v_player.id;
  insert into ranked_mod_presence(player_id,in_code,room_code,selected_mode,visible_to_rank,last_seen_at,updated_at)
    values(v_player.id,v_in_code,v_room,p_mode,p_visible_to_rank,now(),now())
  on conflict(player_id) do update set in_code=excluded.in_code,room_code=excluded.room_code,
    selected_mode=excluded.selected_mode,visible_to_rank=excluded.visible_to_rank,
    last_seen_at=now(),updated_at=now();
  return jsonb_build_object('ok',true,'in_code',v_in_code,'selected_mode',p_mode,'visible_to_rank',p_visible_to_rank,'last_seen_at',now());
end $$;

create or replace function public.ranked_mod_disconnect(p_player_id uuid)
returns boolean language plpgsql security definer set search_path=public as $$
begin
  delete from ranked_queue where player_id=p_player_id;
  delete from ranked_mod_presence where player_id=p_player_id;
  update ranked_players set linked_game_id=null,game_display_name=null,mod_token_hash=null where id=p_player_id;
  return true;
end $$;

create or replace function public.ranked_queue_join(p_player_id uuid,p_mode text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_season uuid; v_mmr integer; v_filter text; v_seen timestamptz; v_in_code boolean; v_selected_mode text;
begin
  if p_mode not in ('1v1','2v2','3v3') then raise exception 'Queue modes are 1v1, 2v2, and 3v3.'; end if;
  if exists(select 1 from ranked_players where id=p_player_id and is_banned) then raise exception 'This account is not allowed to use ranked queues.'; end if;
  if not exists(select 1 from ranked_players where id=p_player_id and linked_game_id is not null and mod_token_hash is not null) then
    raise exception 'Connect your Gorilla Tag account first: run /connect and follow the mod instructions.';
  end if;
  select last_seen_at,in_code,selected_mode,visible_to_rank into v_seen,v_in_code,v_selected_mode,v_filter
    from ranked_mod_presence where player_id=p_player_id;
  if v_seen is null or v_seen < now()-interval '45 seconds' then
    raise exception 'Your mod is not reporting recently. Open Gorilla Tag with the ranked mod enabled and try again.';
  end if;
  if not v_in_code then raise exception 'Join a Gorilla Tag room/code first; the queue only lists players currently in a room.'; end if;
  if v_selected_mode<>p_mode then raise exception 'Your mod game mode is % but you selected %. Change the mod SelectedMode setting to match, then retry.',v_selected_mode,p_mode; end if;
  if v_filter is null then raise exception 'Select a rank or ALL in the mod settings first.'; end if;
  select id into v_season from ranked_seasons where active=true limit 1;
  if v_season is null then raise exception 'No active ranked season. Ask an admin to run /rankedadmin season_start.'; end if;
  select mmr into v_mmr from ranked_ratings where player_id=p_player_id and season_id=v_season and mode=p_mode;
  if v_mmr is null then
    insert into ranked_ratings(player_id,season_id,mode) values(p_player_id,v_season,p_mode) on conflict do nothing;
    select mmr into v_mmr from ranked_ratings where player_id=p_player_id and season_id=v_season and mode=p_mode;
  end if;
  insert into ranked_queue(player_id,mode,mmr_snapshot,joined_at)
    values(p_player_id,p_mode,v_mmr,now())
  on conflict(player_id) do update set mode=excluded.mode,mmr_snapshot=excluded.mmr_snapshot,joined_at=now();
  return jsonb_build_object('status','queued','mode',p_mode,'mmr',v_mmr,'visible_to_rank',v_filter,'queue_time',now());
end $$;

create or replace function public.ranked_queue_list(p_player_id uuid,p_mode text)
returns table(
  player_id uuid, discord_id text, discord_name text, game_display_name text,
  mmr integer, rank_name text, visible_to_rank text, room_code text, joined_at timestamptz
) language plpgsql security definer set search_path=public as $$
declare v_season uuid; v_mmr integer; v_rank text; v_seen timestamptz; v_in_code boolean; v_mode text;
begin
  if p_mode not in ('1v1','2v2','3v3') then raise exception 'Queue modes are 1v1, 2v2, and 3v3.'; end if;
  if not exists(select 1 from ranked_queue where ranked_queue.player_id=p_player_id and ranked_queue.mode=p_mode) then
    raise exception 'Join this mode first by running /queue with the same mode.';
  end if;
  select last_seen_at,in_code,selected_mode into v_seen,v_in_code,v_mode from ranked_mod_presence where ranked_mod_presence.player_id=p_player_id;
  if v_seen is null or v_seen < now()-interval '45 seconds' or not v_in_code or v_mode<>p_mode then
    raise exception 'Your mod must be online, in a room, and set to the selected mode to view the queue.';
  end if;
  select id into v_season from ranked_seasons where active=true limit 1;
  select mmr into v_mmr from ranked_ratings where ranked_ratings.player_id=p_player_id and season_id=v_season and mode=p_mode;
  v_rank := case when v_mmr >= 3200 then 'Champion' when v_mmr >= 2800 then 'Grandmaster'
    when v_mmr >= 2400 then 'Master' when v_mmr >= 2000 then 'Diamond'
    when v_mmr >= 1600 then 'Platinum' when v_mmr >= 1200 then 'Gold'
    when v_mmr >= 800 then 'Silver' else 'Bronze' end;
  return query
  select p.id,p.discord_id,p.discord_name,p.game_display_name,r.mmr,
    case when r.mmr >= 3200 then 'Champion' when r.mmr >= 2800 then 'Grandmaster'
      when r.mmr >= 2400 then 'Master' when r.mmr >= 2000 then 'Diamond'
      when r.mmr >= 1600 then 'Platinum' when r.mmr >= 1200 then 'Gold'
      when r.mmr >= 800 then 'Silver' else 'Bronze' end as rank_name,
    pr.visible_to_rank,pr.room_code,q.joined_at
  from ranked_queue q
  join ranked_players p on p.id=q.player_id and not p.is_banned and p.linked_game_id is not null
  join ranked_mod_presence pr on pr.player_id=p.id
  join ranked_ratings r on r.player_id=p.id and r.season_id=v_season and r.mode=p_mode
  where q.mode=p_mode and q.player_id<>p_player_id
    and pr.in_code=true and pr.room_code is not null
    and pr.last_seen_at >= now()-interval '45 seconds'
    and pr.selected_mode=p_mode
    -- The other player's mod must allow this viewer's current rank, or ALL ranks.
    and (pr.visible_to_rank='ALL' or pr.visible_to_rank=v_rank)
  order by r.mmr desc,q.joined_at asc;
end $$;

-- Every security-definer RPC remains server-only. Never grant these functions to anon/authenticated.
revoke all on all tables in schema public from anon, authenticated;
grant all on all tables in schema public to service_role;
revoke all on all functions in schema public from public, anon, authenticated;
grant execute on all functions in schema public to service_role;
